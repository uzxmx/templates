function foo() {
  console.log('hello world');
}

function bar() {
}

function baz() {
}

foo();
